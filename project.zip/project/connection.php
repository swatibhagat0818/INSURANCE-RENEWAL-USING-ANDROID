<?php

//EDIT Your Database name, Username and Password here
$servername = "localhost";
$username   = "ecoclean";
$password   = "Qz02a6#)jZ2YMv";
$dbname     = "ecoclean_wp1";


 // Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname) or die("User/password is wrong");
// Check connection
if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}
?>